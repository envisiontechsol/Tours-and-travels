const RoutesPath = {
  signin: "/",
  admin: "/admin",
  adminDashboard: "dashboard",
  destination: "destination",
  activity: "activity",
  packageDuration: "package-duration",
  packageType: "package-type",
  tags: "tags",
  tourPackage: "tour-package",
};

export default RoutesPath;
