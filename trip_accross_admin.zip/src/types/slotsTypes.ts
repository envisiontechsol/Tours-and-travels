export type SlotsCategoryType =
  | "MORNING"
  | "EVENING"
  | "AFTERNOON"
  | "FIRST HALF"
  | "SECOND HALF";
