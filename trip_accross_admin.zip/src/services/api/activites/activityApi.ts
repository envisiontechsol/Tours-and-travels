import { ActivityReqBodyType } from "../../../types/activityTypes";
import axiosInstance from "../config";
import { errorHandler } from "../errorHandler";

export const fetchActivitiesReq = async (
  page: number | string,
  size: number | string
) => {
  try {
    const url = `/activities?page=${page}&pageSize=${size}`;
    const res = await axiosInstance.get(url);
    const _data = res?.data?.data || [];
    const _config = res?.data || null;
    const _msg = res?.data?.message;

    return {
      error: false,
      data: _data,
      config: _config,
      message: _msg,
      errorMsg: "",
    };
  } catch (err) {
    const error = errorHandler(err, "fetchActivitiesReq");
    throw { error: true, data: "", message: "", errorMsg: error };
  }
};
export const fetchActivitiesByTourIdReq = async (tourId: string) => {
  try {
    const url = `/tour-packages/${tourId}/activities`;
    const res = await axiosInstance.get(url);
    const _data = res?.data?.data || [];
    const _config = null;
    const _msg = res?.data?.message;

    return {
      error: false,
      data: _data,
      config: _config,
      message: _msg,
      errorMsg: "",
    };
  } catch (err) {
    const error = errorHandler(err, "fetchActivitiesByTourIdReq");
    throw { error: true, data: "", message: "", errorMsg: error };
  }
};

export const addActivityReq = async (body: any) => {
  try {
    const url = `/activities`;
    const res = await axiosInstance.post(url, body, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    const _data = res?.data;
    const _msg = res?.data?.message;

    return { error: false, data: _data, message: _msg, errorMsg: "" };
  } catch (err) {
    const error = errorHandler(err, "addActivityReq");
    throw { error: true, data: "", message: "", errorMsg: error };
  }
};
export const updateActivityReq = async (id: string, body: any) => {
  try {
    const url = `/activities/${id}`;
    const res = await axiosInstance.patch(url, body, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    const _data = res?.data;
    const _msg = res?.data?.message;

    return { error: false, data: _data, message: _msg, errorMsg: "" };
  } catch (err) {
    const error = errorHandler(err, "updateActivityReq");
    throw { error: true, data: "", message: "", errorMsg: error };
  }
};

export const fetchActivitiesByCatReq = async (
  cat: string,
  destinationName: string
) => {
  try {
    const url = `/activities/search?destinationSlug=${destinationName}&category=${cat}&page=1&pageSize=${50}`;
    const res = await axiosInstance.get(url);
    const _data = res?.data;
    const _msg = res?.data?.message;

    return { error: false, data: _data, message: _msg, errorMsg: "" };
  } catch (err) {
    const error = errorHandler(err, "fetchActivitiesReq");
    throw { error: true, data: "", message: "", errorMsg: error };
  }
};
