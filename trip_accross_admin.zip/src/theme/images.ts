import AppLogo from "../assets/logos/logo.jpeg";

export const IMAGES = {
  logo: AppLogo,
};
