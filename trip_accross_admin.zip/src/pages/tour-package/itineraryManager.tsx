import React, { useState, useMemo, useEffect } from "react";
import SelectInput from "../../components/forms/elements/selectInput";
import {
  fetchActivitiesByCatReq,
  fetchActivitiesByTourIdReq,
} from "../../services/api/activites/activityApi";
import {
  ActivityResType,
  ItineraryActivityResType,
} from "../../types/activityTypes";
import { SlotsCategoryType } from "../../types/slotsTypes";
import { slotsCategory } from "../../constants/slotsCategory";

type DayData = {
  day: Option;
  cards: ActivityResType[];
};

interface Option {
  label: string;
  value: string | number;
}

type TimeSlot = SlotsCategoryType;

export default function ItineraryManager({
  tourId,
  numberOfDays,
  onChangeItinerary,
  destinationName,
}: {
  tourId?: string;
  numberOfDays: number;
  destinationName?: string;
  onChangeItinerary: (d: DayData[]) => void;
}) {
  const PREDEFINED_DAYS: Option[] = useMemo(() => {
    let opts = [];

    for (let index = 0; index < numberOfDays; index++) {
      opts.push({
        label: `Day ${index + 1}`,
        value: index + 1,
      });
    }
    return opts;
  }, [numberOfDays]);

  const TIME_SLOTS = !!slotsCategory?.length
    ? slotsCategory?.map((i) => i.id)
    : [];

  const [selectedDay, setSelectedDay] = useState<Option | null>(null);
  const [selectedCards, setSelectedCards] = useState<ActivityResType[]>([]);
  const [cardsList, setCardsList] = useState<ActivityResType[]>([]);
  const [days, setDays] = useState<DayData[]>([]);

  const [selectedCategory, setSelectedCategory] = useState<TimeSlot | null>(
    null
  );
  const [searchText, setSearchText] = useState("");

  const [addSectionError, setAddSectionError] = useState("");
  const [selectionError, setSelectionError] = useState("");
  const [loadingCards, setloadingCards] = useState(true);

  // ---------------------- FILTER DAYS ----------------------
  const availableDays = useMemo(() => {
    const usedValues = days.map((d) => d.day.value);
    return PREDEFINED_DAYS.filter((d) => !usedValues.includes(d.value));
  }, [days, PREDEFINED_DAYS]);

  useEffect(() => {
    onChangeItinerary(days || []);
  }, [days]);

  // ---------------------- FILTER CARDS BASED ON SEARCH ----------------------
  const filteredCards = useMemo(() => {
    return cardsList.filter((c) =>
      c.title.toLowerCase().includes(searchText.toLowerCase())
    );
  }, [cardsList, searchText]);

  // ---------------------- ADD CARD TO SELECTION ----------------------
  const addCard = (card: ActivityResType) => {
    setSelectionError("");

    if (
      selectedCards.some(
        (selectedCard) =>
          selectedCard.category === "FIRST HALF" &&
          (card.category === "MORNING" || card.category === "AFTERNOON")
      )
    ) {
      setSelectionError(`Activity is already selected for ${card.category}`);
      return;
    }
    if (
      selectedCards.some(
        (selectedCard) =>
          selectedCard.category === "SECOND HALF" &&
          (card.category === "EVENING" || card.category === "AFTERNOON")
      )
    ) {
      setSelectionError(`Activity is already selected for ${card.category}`);
      return;
    }

    if (
      selectedCards.some(
        (selectedCard) => selectedCard.category === card.category
      )
    ) {
      setSelectionError(`Activity is already selected for ${card.category}`);
      return;
    }
    // Check if card already exists in selection
    if (selectedCards.some((selectedCard) => selectedCard.id === card.id)) {
      setSelectionError("This activity is already selected");
      return;
    }

    // Check if we've reached the maximum (3 activities)
    if (selectedCards.length >= 3) {
      setSelectionError(
        "Maximum 3 activities allowed. Remove one to add another."
      );
      return;
    }

    setSelectedCards((prev) => [...prev, card]);
  };

  // ---------------------- REMOVE CARD FROM SELECTION ----------------------
  const removeCard = (cardId: string) => {
    setSelectedCards((prev) => prev.filter((card) => card.id !== cardId));
    setSelectionError("");
  };

  // ---------------------- ADD DAY ----------------------
  const handleAdd = () => {
    if (!selectedDay) {
      setAddSectionError("Please select a day");
      return;
    }

    if (selectedCards.length < 2) {
      setAddSectionError("Please select minimum 2 activities");
      return;
    }

    if (selectedCards.length > 3) {
      setAddSectionError("Maximum 3 activities allowed");
      return;
    }

    setAddSectionError("");

    setDays((prev) => [
      ...prev,
      { day: selectedDay, cards: [...selectedCards] },
    ]);

    // Reset section
    setSelectedDay(null);
    setSelectedCards([]);
    setSearchText("");
    setSelectedCategory(null);
    setCardsList([]);
  };

  // ---------------------- REMOVE DAY ----------------------
  const removeDay = (dayValue: string | number) => {
    setDays((prev) => prev.filter((day) => day.day.value !== dayValue));
  };

  // ---------------------- API CALL WHEN CATEGORY CHANGES ----------------------
  useEffect(() => {
    if (!selectedCategory || !destinationName) {
      setCardsList([]);
      return;
    }
    (async () => {
      try {
        setloadingCards(true);
        const res = await fetchActivitiesByCatReq(
          selectedCategory,
          destinationName
        );
        setCardsList(res?.data?.items || []);
        setSearchText("");
        setSelectionError("");
      } catch (error) {
        setCardsList([]);
      } finally {
        setloadingCards(false);
      }
    })();
  }, [selectedCategory, destinationName]);

  function mapApiItineraryToDays(
    apiData: ItineraryActivityResType[]
  ): DayData[] {
    if (!apiData || apiData.length === 0) return [];

    // Group activities by dayNumber
    const grouped: Record<number, ActivityResType[]> = {};

    apiData.forEach((item) => {
      if (!grouped[item.dayNumber]) grouped[item.dayNumber] = [];
      grouped[item.dayNumber].push(item);
    });

    // Convert to DayData[]
    const result: DayData[] = Object.entries(grouped).map(
      ([dayNum, cards]) => ({
        day: {
          label: `Day ${dayNum}`,
          value: Number(dayNum),
        },
        cards: cards,
      })
    );

    return result;
  }

  useEffect(() => {
    const getActivites = async () => {
      try {
        const res = await fetchActivitiesByTourIdReq(tourId || "");
        if (Array.isArray(res?.data)) {
          const mapped = mapApiItineraryToDays(res?.data);
          setDays(mapped);
        }
      } catch (error) {
        setDays([]);
      }
    };
    if (tourId) {
      getActivites();
    }
  }, [tourId]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 p-4 gap-4 bg-gray-100 rounded">
      {/* ---------------------- LEFT SECTION ---------------------- */}
      <div>
        <section className="bg-white p-6 rounded-xl shadow-md w-full">
          <h2 className="text-xl font-bold mb-4">Select Activities</h2>

          {/* Time Slot Selection */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Time Slot
            </label>
            <div className="flex gap-2 flex-wrap">
              {TIME_SLOTS.map((slot) => (
                <button
                  key={slot}
                  type="button"
                  className={`px-4 py-2 rounded-lg border transition-colors ${
                    selectedCategory === slot
                      ? "bg-blue-600 text-white border-blue-600"
                      : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                  }`}
                  onClick={() => setSelectedCategory(slot)}
                >
                  {slot}
                </button>
              ))}
            </div>
          </div>

          {/* Search Bar */}
          <input
            type="text"
            placeholder="Search activities..."
            className="border p-2 rounded-md w-full my-4"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            disabled={!selectedCategory}
          />

          {/* Selection Error */}
          {selectionError && (
            <p className="text-red-500 text-sm mb-3">{selectionError}</p>
          )}

          {/* Activities List */}
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {!loadingCards &&
              filteredCards.map((card) => (
                <div
                  key={card.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => addCard(card)}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="font-medium">{card.title}</span>
                  </div>
                  <button
                    type="button"
                    className="text-blue-600 hover:text-blue-800 font-medium text-sm"
                  >
                    Add +
                  </button>
                </div>
              ))}

            {filteredCards.length === 0 && selectedCategory && (
              <p className="text-gray-400 text-sm text-center py-4">
                No activities found for {selectedCategory}.
              </p>
            )}
            {loadingCards && (
              <p className="text-gray-400 text-sm text-center py-4">
                Loading...
              </p>
            )}

            {!selectedCategory && (
              <p className="text-gray-400 text-sm text-center py-4">
                Please select a time slot to view activities.
              </p>
            )}
          </div>
        </section>
      </div>

      {/* ---------------------- RIGHT SECTION ---------------------- */}
      <div className="space-y-4">
        {/* Add Section */}
        <section className="bg-white p-6 rounded-xl shadow-md w-full">
          <h2 className="text-xl font-bold mb-4">Add Day Plan</h2>

          {/* Day Dropdown */}
          <SelectInput
            label="Select Day"
            options={availableDays}
            value={selectedDay}
            onChange={(val) => {
              setSelectedDay(val);
              setAddSectionError("");
            }}
          />

          {/* Selected Activities Preview */}
          <div className="mt-4">
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Selected Activities ({selectedCards.length}/3)
              </label>
              {selectedCards.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSelectedCards([])}
                  className="text-red-500 hover:text-red-700 text-sm font-medium"
                >
                  Clear All
                </button>
              )}
            </div>

            <div className="min-h-[120px] border-2 border-dashed border-gray-300 p-4 rounded-lg bg-gray-50">
              {selectedCards.length === 0 ? (
                <p className="text-gray-400 text-sm text-center py-4">
                  Select activities (min 2, max 3)
                </p>
              ) : (
                <div className="space-y-2">
                  {selectedCards.map((card) => (
                    <div
                      key={card.id}
                      className="flex items-center justify-between px-4 py-3 bg-white rounded-lg border border-gray-200 shadow-sm"
                    >
                      <span className="font-medium text-gray-800">
                        {card.title}{" "}
                        <span className="text-sm text-gray-500">
                          ({card.category})
                        </span>
                      </span>
                      <button
                        type="button"
                        onClick={() => removeCard(card.id)}
                        className="text-red-500 hover:text-red-700 font-bold text-lg w-6 h-6 flex items-center justify-center rounded-full hover:bg-red-50 transition-colors"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Error Message */}
          {addSectionError && (
            <p className="text-red-500 text-sm mt-2 font-medium">
              {addSectionError}
            </p>
          )}

          {/* Add Button */}
          <button
            type="button"
            onClick={handleAdd}
            className={`w-full mt-4 px-4 py-3 rounded-lg font-medium transition-colors ${
              selectedCards.length >= 2
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
            disabled={selectedCards.length < 2}
          >
            Add Day Plan ({selectedCards.length}/3 activities)
          </button>
        </section>

        {/* View Section */}
        <section className="bg-white p-6 rounded-xl shadow-md w-full">
          <h2 className="text-xl font-bold mb-4">Your Itinerary</h2>

          {days.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              No days planned yet. Add your first day plan above.
            </p>
          ) : (
            <div className="space-y-4">
              {days.map((day, index) => (
                <div
                  key={day.day.value}
                  className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm"
                >
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-semibold text-lg text-gray-800">
                      {day.day.label}
                    </h3>
                    <button
                      type="button"
                      onClick={() => removeDay(day.day.value)}
                      className="text-red-500 hover:text-red-700 text-sm font-medium"
                    >
                      Remove
                    </button>
                  </div>

                  <div className="space-y-2">
                    {day.cards.map((card) => (
                      <div
                        key={card.id}
                        className="px-3 py-2 bg-green-50 border border-green-200 rounded-md text-green-800 font-medium"
                      >
                        {card.title}
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="text-sm text-gray-600">
                      {day.cards.length} activity
                      {day.cards.length !== 1 ? "ies" : ""} planned
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
