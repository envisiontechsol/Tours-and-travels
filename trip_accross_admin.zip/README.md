# React + Vite Project

This is a React project with [Vite](https://vitejs.dev/).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:5173](http://localhost:5173) with your browser to see the result.

You can start editing the page by modifying `src/App.jsx`. The page auto-updates as you edit the file.

This project uses `Tailwind CSS` for styling, providing a utility-first CSS framework.
